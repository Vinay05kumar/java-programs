/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	   Scanner s1=new Scanner(System.in);
	   System.out.println("Enter the String :");
	   String s=s1.nextLine().toLowerCase();
	   //System.out.println("Enter the Character :");
	   //char ch=s1.nextLine().charAt(0);
	   //char ch='1';
	   //int i=(int) ch;
	   //System.out.println(Character.isDigit(ch));
	   //System.out.println(i);
	   
	   //System.out.println(count);
	   int count=0,countc=0,countno=0,countcon=0,countspec=0;
	   for(int i=0;i<s.length();i++){
	   if((int)s.charAt(i)>=97 && (int)s.charAt(i)<=122 ){
	   if(s.charAt(i)=='a'||s.charAt(i)=='i'||s.charAt(i)=='o'||s.charAt(i)=='u'||s.charAt(i)=='e'){
	       count++;
	   }
	   else{
	       
	   countcon++;
	   }
	   }
	   else if(s.charAt(i)==' '){
	      countc++;
	   }else if(Character.isDigit(s.charAt(i))){
	       countno++;
	   }
	   else{
	       countspec++;
	   }
	   }
	   System.out.println(count);
	   System.out.println(countc);
	    System.out.println(countno);
	     System.out.println(countcon);
	     System.out.println(countspec);
	}
}
// 	   String s=s1.next().toLowerCase();
// 	   boolean ispalindrome=true;
// 	   for(int i=0;i<s.length()/2;i++){
// 	       if(s.charAt(i)!=s.charAt(s.length()-i-1))        //// check  ispalindrome
// 	           ispalindrome=false;
// 	           break;
// 	   }
// 	   System.out.println(ispalindrome);
// 	}
	
// }
	   //String s=new StringBuilder("madam").toString();
	   //String s2=new StringBuilder(s).reverse().toString();
	   
	   //System.out.println(s);
	   //System.out.println(s2);
	   //System.out.println(s.equals(s2));
	   //System.out.println(s.equalsIgnoreCase(new StringBuilder(s).reverse().toString()));//true
	   //System.out.println(s.equals(new StringBuilder(s).reverse().toString()));//true
	   	   
	   	   
	   	   
	   //int n=s1.nextInt();
	   //String s2="hello";
	   //System.out.println(s2.split());
	   //for(int i=1;i<=n;i++){
	   //System.out.println(" ".repeat(n-i)+s.repeat(i));
	   //}
	   //for(int i=1;i<=n;i++){
	   //System.out.println(" ".repeat(n-i)+"* ".repeat(i));
	   //}
	   
	   
	   
	   
	   ////int n=s.length();
	   // String s2=new String("Hello world!");
	   // String s3="Hello";
	   //   String s1="Hello World! , How are you?";
	   
	   // System.out.println(s.startsWith("Hello")); // true -- if it startswith Hello the print true
    //     System.out.println(s.toUpperCase().startsWith("HELLO"));
	   // String a1[]=s.split(",");
	   //  System.out.println(a1[0]);// it will create an array of String
	   //  System.out.println(a1[1]);
	   //  System.out.println(a1[2]);  
	   //  for(int i=0;i<=2;i++){
	   //     System.out.println(a1[i]); 
	   //  }
	   // int n=s1.length();
	   // System.out.println(n);
	   //for(int i=0;i<s1.length();i++)
	   //if(a==s1.charAt(i)||e==s1.charAt(i)||i==s1.charAt(i)||o==s1.charAt(i)||u==s1.charAt(i))
	   // System.out.print(s1.charAt(i));  ////
	   // System.out.println(s1.substring(0,5)); //Hello
	   // System.out.println(s1.equalsIgnoreCase(s2)); //true
	   // System.out.println(s1.equals(s2));//false
	    
	   //  System.out.println(s1.toLowerCase());//Hello world!
	   //  System.out.println(s2.toUpperCase()); //HELLO WORLD!
	   //  System.out.println(s1.indexOf('d')); //10
	   //  System.out.println(s1.lastIndexOf('l'));//9
	   //  System.out.println(s1.indexOf('l'));//2
	   //  System.out.println(s1.replace('l','x'));//Hexxo Worxd!
	   //  System.out.println(s1.contains("World")); // if substring is present then return true
	   //  System.out.println(s1.trim()); // it will trim the before and after spaces in the String
	     
	     
	     
// 	}
// }
	    
	    
// 	    String s2=new String("Hello");
// 		System.out.println(s1);
// 		System.out.println(s2);
// 		System.out.println(s1==s2); //false
// 		System.out.println(s1.equals(s2));  //true to compare the String
		
// 	}
// }
