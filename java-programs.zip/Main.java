/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

// *******************************************************************************/
// import java.util.Scanner;
// public class Main {
//     public static void main(String[] args){
//         Scanner s1=new Scanner (System.in);
//          int n=s1.nextInt();

    
//       System.out.println("the sum of "+n+" prime numbers sum is:"+sumofprime(n));  
//     }
//     public static int sumofprime(int n){
//         int num=2;
//         int count=0;
//         int sum=0;
//         while(count!=n){
//         if(prime(num)){
//         sum+=num;
//         count++;
        
//         }
//         num++;
//         }
//          return sum;
        
//     } 
//     public static boolean prime(int num){
        
//         for(int i=2;i<=num/2;i++){
//             if(num%i==0){
//                 return false;
                
//             }
            
//         }
//         return true;
//     }
// }    
      
      
      
      
// //public class FibonacciSum {
//     public static int fibonacci(int n) {
//         if (n <= 1) {
//             return n;
//         }
//         return fibonacci(n - 1) + fibonacci(n - 2);
//     }

//     public static int sumFibonacci(int n) {
//         if (n <= 0) {
//             return 0;
//         }
//         return fibonacci(n) + sumFibonacci(n - 1);
//     }

//     public static void main(String[] args) {
//         int n = 7; // Calculate sum of first 7 Fibonacci numbers
//         int sum = sumFibonacci(n);
//         System.out.println("Sum of the first " + n + "\n Fibonacci numbers is: " + sum);
//     }

// }


//          int n=s1.nextInt();
//           int sum=0;
//         for(int j=2;j<=n;j++){
//             if (isPrime(j)){
//                 sum+=j;
       
//         }
//         }
//          System.out.print(sum+" ");
//     }
//     public static boolean isPrime(int n){
//         int count =0;
//         for(int i=2;i<=Math.sqrt(n);i++){
//             if(n%i==0){                                      //// print sum of  prime no's from 1 to n
//                 count++;
//             }
            
//         }
//         if(count==0){
//             return true;
//         }
//         else{
//             return false;
//         }
//     }
// }
         
         
//          int sum=0;
//         for(int j=2;j<=n;j++){
//             if (isPrime(j)){
//                 sum+=j;
       
//         }
//         }
//          System.out.print(sum+" ");
//     }
//     public static boolean isPrime(int n){
//         int count =0;
//         for(int i=2;i<=n/2;i++){
//             if(n%i==0){                                      //// print sum of  prime no's from 1 to n
//                 count++;
//             }
            
//         }
//         if(count==0){
//             return true;
//         }
//         else{
//             return false;
//         }
//     }
// }
        
        
        
//         int n=s1.nextInt();
//         for(int j=1;j<=n;j++){
//             if (isPrime(j)){
//         System.out.print(j+" ");
//         }
//         }
//     }
//     public static boolean isPrime(int n){
//         int count =0;
//         for(int i=1;i<=n;i++){
//             if(n%i==0){                                      //// print prime no's from 1 to n
//                 count++;
//             }
            
//         }
//         if(count==2){
//             return true;
//         }
//         else{
//             return false;
//         }
//     }
// }
//         int count=0;
//         int countodd=0;
//          while(n!=0){
//             int digit=n%10;
//             if(digit%2==0){
//                 count++;
//             } else{
//                 countodd++;
//             }                     //// count of even & odd numbers in given input
//             n/=10;                                       
//         }
//         System.out.println(count);
//         System.out.println(countodd);
//     }
// }
        
        
        
//         int count=0;
//          while(n!=0){
//             int digit=n%10;
//             if(digit==0){
//                 count++;
//             }                      //// count of zeros
//             n/=10;                                       
//         }
//         System.out.println(count);
//     }
// }
        // int sum=0;
        //  int temp = n;
    //     int rev=0;
    //     while(n!=0){
    //         int digit=n%10;
    //         rev =rev*10+digit;                       //// revese of numbers
    //         n/=10;                                       
    //     }
    // System.out.println(rev);
    // }}  
    
    
    // int temp=n;
    //   int rev=0;
    //     while(n!=0){
    //         int digit=n%10;
    //         rev =rev*10+digit;
    //         n/=10;                                       
    //     }
    // System.out.println(rev);                          ////palendrome of numbers
    // if(rev==temp){
    //     System.out.println("its palendrome");
    // }else{
    //     System.out.println("its not");
    // }
// }
// }
        // int l=String.valueOf(n).length();
        
//         System.out.println(fact(n));
//     }
// public static int fact(int n){
//     if(n==1){
//         return 1;
                                                ////factorial number using recursion
//     }else {
//         return n*fact(n-1);
//     }
// }
// }
//     //     while(n!=0){
//     //     int digit =n%10;
//     //     sum +=Math.pow(digit,l);
//     //     n=n/10;
//     // }
//     // System.out.println(sum);                                                  /////armstrong number 
//     // if (sum == temp){
//     //     System.out.println("its an armstrong number");
//     // }else{
//     //     System.out.println("its not a armstrong number");
//     // }
//     while(n>0){
//         int fact=1;
//         int digit = n%10;
    
//         for (int i=1;i<=digit;i++){                                             /////strong number
//             fact*=i ;
//         }
//         sum+=fact;
//         n/=10;
// }
// System.out.println(sum);
// if(sum==temp){
//     System.out.println("its a strong number");
// }else{
//     System.out.println("its not strong number");
// }
// }
// }
        // for (int i = 1; i <= n; i++) {
        //     // Print spaces
        //     for (int j = 1; j <= n - i; j++) {
        //         System.out.print(" ");
        //     }

        //     // Print increasing numbers
        //     for (int j = 1; j <= i; j++) {
        //         System.out.print(j);
        //     }

        //     // Print decreasing numbers
        //     for (int j = i - 1; j >= 1; j--) {
        //         System.out.print(j);
        //     }

        //     // Move to next line
        //     System.out.println();
        // }
        
        
    


// import java.util.Scanner;

// public class Main {
//     public static void main(String[] args) {
//         Scanner s = new Scanner(System.in);
//         System.out.print("Enter number of prime numbers to sum: ");
//         int n = s.nextInt(); 

//         int count = 0, num = 2, sum = 0;

//         while (count < n) {
//             boolean isPrime = true;

//             for (int i = 2; i <= num / 2; i++) {
//                 if (num % i == 0) {
//                     isPrime = false;
//                     break;
//                 }
//             }

//             if (isPrime) {
//                 sum += num;
//                 count++;
//             }

//             num++;
//         }

//         System.out.println("Sum of first " + n + " prime numbers is: " + sum);
//     }
// }

// import java.util.Scanner;

// public class Main {
//     public static void main(String[] args) {
//         Scanner s1 = new Scanner(System.in);
//         System.out.print("Enter a number: ");
//         int m1 = s1.nextInt();

//         int temp = m1;
//         int l = String.valueOf(m1).length();
      
        // int sum=0;
//         while(m1>0){
//             int digit=m1%10;
//               int fact = 1;
//             for(int i=1;i<=digit;i++){
//                 fact*=i;
//             }
//             sum+=fact;
            
//             m1=m1/10;
//         }
//         if(sum==temp){
//             System.out.println(" its a strong no");
//         }else{
//             System.out.println("its not a strong no");
//         }
        
//     }  
// }    
        
        
        
// import java.util.Scanner;

// public class Main {
//     public static void main(String[] args) {
//         Scanner s1 = new Scanner(System.in);
//         System.out.print("Enter a number: ");
//         int m1 = s1.nextInt();

//         int temp = m1;
//         int l = String.valueOf(m1).length();
//         int sum = 0;

//         while (m1 > 0) {
//             int digit = m1 % 10;
//             sum += Math.pow(digit, l);
//             m1 = m1 / 10;
//         }

//         if (sum == temp) {
//             System.out.println("It is an Armstrong number.");
//         } else {
//             System.out.println("It is NOT an Armstrong number.");
//         }
//     }
// }

    //  for(int i=0;i<=m1;i++){
    //      System.out.println(fib(i)+"  ");
    //  }
     
    //  int n=s1.nextInt();
//      int count =0;
        // int sum =0;
//      for(int i=1;i<=m1;i++){
//      for(int j=1;j<=m1;j++){
//          if(m1%i==0){
//              count++;
//          }
// }
        







//         public static int fib(int m1){
//             // int f0=0;
//             // int f1=1;
//           if(m1==0){
//               return 0;
//           }
//           else if(m1==1){
//               return 1;                                              /////fibonic series using recursion
//           }
//           else{
//               return (fib(m1-1)+fib(m1-2));
//           }
//         }
	
// }

//         for (int i = 2; i <= m1; i++) {
//             boolean isPrime = true;

//             for (int j = 2; j <= i / 2; j++) {
//                 if (i % j == 0) {
//                     isPrime = false;
//                     break;                                       //////sum of prime no's
//                 }
//             }

//             if (isPrime) {
//                 sum += i;
//             }
//         }

//          System.out.println("Sum of prime numbers up to " + m1 + " is: " + sum);
//     }     
// }
         
         
         
         
//      }if(count==2){
//          sum=sum+m1;
//      }
     
//      }
//      System.out.println(sum);
// 	}
// }
     
     
//      Isprime(m1);
    //  System.out.println(fact(m1));
    //  int m2=s1.nextInt();
    // int m2=s1.nextInt();
    // int a=2*3/4+2*5%3;                   
// 	} 
	
// 	public static int fact(int m1){
// 	    int fact=1;
// 	    for(int i =1 ; i<=m1 ; i++){
// 	        fact*=i;
// 	    }                                               /////factorial of no
// 	    return fact;
// 	}


//  int count=0;
//         while(m1>=0){
//         for(int i=1;i<=m1;i++){
//       for(int j=2;j<=m1/2;j++){
//           if(i%j==0){
//               count++;
//           }                                              ////prime no
//       }
//       if (count==0){
//           sum=sum+i;
//         //   System.out.println("its prime no");
//       }
//         }
//       System.out.println(sum);
// // }
// }
// }
//       }

// int count=0;
//       for(int i=2;i<=m1-1;i++){
//           if(m1%i==0){
//               count++;
//                    break;
//           }                                              ////prime no
//       }                                                     ///o(n-1)
//       if (count==0){
//           System.out.println("its prime no");
//       }else{
//           System.out.println("its not prime no");
//       }
// int sum=0;
// int count=0;
//       for(int i=1;i<=m1;i++){
//           if(m1%i==0){
//               count++;
//           }  
//          ////prime no
//                                                           ///o(n/2)
//       if (count==0){
//           sum+=i;
//       }     
//       }  
//       System.out.println(sum);



//   public static Boolean Isprime(int m1){
//       int count = 0;
//      for(int i=1;i<=m1;i++){
//          if (m1%i==0){
//              count++;
//          }
//      }
//          if (count==2){
//              return true;
//          }
//          else{
//              return false;
//          }
//      } 
  
// import java.util.Scanner;
// public class Main {
//     public static void main(String[] args) {
//         Scanner s1 = new Scanner(System.in);
//         System.out.print("Enter a number: ");
//         int m1 = s1.nextInt();
//         
//         if (Isprime(m1)) {
//             return true;
            
//         } 
//         else {
            
//             return false;
//         }
        
//         s1.close(); // Good practice to close the scanner
//     }

//     public static boolean Isprime(int m1) {
//         int count = 0;
//         for (int i = 1; i <= m1; i++) {
//             if (m1 % i == 0) {
//                 count++;
//             }
//         }
//         return count == 2;
//     }
// }



//     int a = 5;
//     int b = 10;
//     // int temp = a;
//     // a=b;
   
//     // b=temp;
// //   a=a+b;
// //   b=a-b;
// //   a=a-b;
    
   
//     System.out.println(a);
//     System.out.println(b);
//  int stars=1;
//   int n =5;
//   for(int i=5;i>=1;i--){
//       for (int j=1;j<=stars;j++){
//           System.out.print("  *");
//       }
//       stars++;
//       System.out.println();
//   } 
//      int stars=5;
//   int n =5;
//   for(int i=5;i>=1;i--){
//       for (int j=1;j<=stars;j++){
//           System.out.print("  *");
//       }
//       stars--;
//       System.out.println();
//   } 
//     int stars=5;
//   int n =s1.nextInt();
//   for(int i=1;i<=n;i++){
//       for (int j=1;j<=stars;j++){
//           System.out.print("  *");
//       }
//       stars--;
//       System.out.println();
//   } 
    
      
//   int n =s1.nextInt();
//   int stars=n;
//   for(int i=1;i<=n;i++){
//       for (int j=1;j<=stars;j++){
//           System.out.print("  *");
//       }
//       stars--;
//       System.out.println();
//   } 
    
    // int n =s1.nextInt();
//   int stars=n*2-1;
//   int spaces=0;
//   for(int i=1;i<=n;i++){
//       for (int k=1;k<=spaces;k++){
//           System.out.print(" ");
//       }
//       for (int j=1;j<=stars;j++){
//           System.out.print("*");
//       }
//       spaces++;
//       stars = stars - 2;
//       System.out.println();
//   }
//     }
// }

//  int n =s1.nextInt();
 
//   int stars=n;
 
//   for (int j=1;j<=5;j++){
//   int spaces=0;
//   int space=n-1;

  
//      for(int i=1;i<=n;i++){
//       for (int k=1;k<=spaces;k++){
//           System.out.print(" ");
//       }
//           System.out.println("*****");
      
//       spaces++;
//      }  
   
//   for(int i=1;i<=n;i++){
//       for (int k=1;k<=space;k++){
//           System.out.print(" ");
//       }
     
//           System.out.println("*****");
      
//         space--;
//   }  
// 	}
//   

   
   
//   int n =4;
//   int stars=n*2;
//   int space = 0;
//   int stars01=n*2-1;
//   for(int i=1;i<=5;i++){
//       for (int k=1;k<=space;k++){
//           System.out.print(" ");
//       }
//       for (int j=1;j<=stars;j++){
//           System.out.print("*");
//       }
//       stars=stars-2;
//       space--;
//       System.out.println();
//   } 
//   int n =s1.nextInt();
   
//   int stars01=1;
//   int spaces01=n-1;
//   for(int i=1;i<=n;i++){
//       for (int k=1;k<=spaces01;k++){
//           System.out.print(" ");
//       }
//       for (int j=1;j<=stars01;j++){
//           System.out.print("*");
//       }
//       spaces01--;
//       stars01 = stars01 + 2;
//       System.out.println();
//   }
//   int stars=n*2-3;
//   int spaces=1;
//   for(int i=1;i<=n-1;i++){
//       for (int k=1;k<=spaces;k++){
//           System.out.print(" ");
//       }
//       for (int j=1;j<=stars;j++){
//           System.out.print("*");
//       }
//       spaces++;
//       stars = stars - 2;
//       System.out.println();
//   }
// int n=s1.nextInt();
// int stars01=1;
// //   int spaces01=n-1;
//   for(int i=1;i<=n;i++){
//     //   for (int k=1;k<=spaces01;k++){
//     //       System.out.print(" ");
//     //   }
//       for (int j=1;j<=stars01;j++){
//           System.out.print(i);
//       }
//       stars01++;
//       System.out.println();
//   }

// int n=s1.nextInt();
// int stars01=1;
// //   int spaces01=n-1;
// int num = 1;
//   for(int i=1;i<=n;i++){
//     //   for (int k=1;k<=spaces01;k++){
//     //       System.out.print(" ");
//     //   }
//       for (int j=1;j<=stars01;j++){
//           System.out.print(num++ +" ");
//       }
//       stars01++;
//       System.out.println();
//   }
// int n=s1.nextInt();
// int stars01=1;
// char ch = 'A';
// //   int spaces01=n-1;
//   for(int i=1;i<=n;i++){
//     //   for (int k=1;k<=spaces01;k++){
//     //       System.out.print(" ");
//     //   }
//       for (int j=1;j<=stars01;j++){
//           System.out.print(ch++ + " ");
//       }
//       stars01++;
//       System.out.println();
//   }
    // System.out.println(a);
//   int m2=s1.nextInt();
//   if(m1>=0&&m1<=2025){
    

//         int m2=2025-m1;
//     if(m2>=65){
//         System.out.println("senior citizen");
//     }
//     else{
//         System.out.println("not senior citizen");
//     }
// }else{
//     System.out.println("invalid input");
// }
    //   m1--;
    //   int m2=--m1;
    // int m2=m1--;
    // int m2=m1++;
    // int m2=++m1;
    // int m2=m1++ + ++m1 - --m1;
    // int m3=m1++ - ++m2 - m1-- + m2--;
    // int m3=--m1 + --m2 * ++m1 / --m2;
    
//    Loops
  
    // for(int i=1;i<=m1;i++){
    //     if(i%2!=0){
    //   System.out.print(i+" ");
    // }
    // int sum=0;
    // for(int i=1;i<=m1;i++){
    //     sum+=i;
    // }
    //  System.out.println(sum);
    // int sum=0;
    // for(int i=1;i<=m1;i++){
    //     if(i%2!=0){
    //         sum+=i;
    //     }
    // }
    
    //  for(int i=1;i<=10;i++){
         
    //   System.out.printf("%d * %d = %d \n",m1,i,m1*i);
    // }
    // for(int i=1;i<=200;i++){
         
    //   System.out.printf("%-2d * %2d = %3d \n",  m1,  i,   m1*i);
    // }
    // for(int i=1;i<=200;i++){
         
    //   System.out.printf("%-2d * %2d = %3d \n",  m1,  i,   m1*i);
    // }
    
    //  for(int i=m1;i<=m2;i++){
    //     if(i%2==0){
    //   System.out.print(i+" ");
    // }
    //  }
    // if((m1%400==0)&&(m1%100==0)||(m1%4==0)){    
    //     System.out.println(m1+" is leap years");
    // }
    // else{
    //      System.out.println(m1+" is not  leap years");
    // }
    // for(int i=m2;i<=m3;i++){
    // if((i%400==0)||(i%4==0)&&(i%100!=0)){     within the range of years
    //     System.out.println(i+" is leap years");
    // }
    // }
    // System.out.println(m1);
    // System.out.println(m2);
//   int m3=0;
//   int sum=0;
//     for(int i=1;i<=8;i++){
//     m3=m1+m2;  
//     if(m3%2==0)
    
// sum of even fibonic series
//     // System.out.println(m3);
//     sum+=m3;
//     m1=m2;
//     m2=m3;
//     }
// System.out.println(sum);
// int i=0;
//   for(;;System.out.print( " hi")){
//   i++;
//   if(i==5){
//       break;
//   }
//   }
// for(int i=1;i<=5;i++){
  
//     for(int j=1;j<=5;j++){
//         System.out.print( i+""+j+" ");
        
//     }
//     System.out.println();
// }
//     for(int i=1;i<=5;i++){
  
//     for(int j=1;j<=5;j++){
//         System.out.print(" * " );pattren
        
//     }
//     System.out.println();
// }
    //  for(int i=1;i<=5;i++){
  
    // for(int j=1;j<=i;j++){
    //     System.out.print(" * " );  //// pattren
        
    // }
    //  }
    
//  for(int i=1;i<=5;i++){
  
//     for(int j=1;j<=5;j++){
//       if(i<=j)
//         System.out.print( " * ");
//       else
//       System.out.print(" ");
        
//     }
//     System.out.println();
// }

//     }
// }
// public class Main
// {
// 	public static void main(String[] args) {
// 	    System.out.println("For A: ");
// 		for (int i=1;i<=5 ;i++ ){
// 		    for(int j=1;j<=9;j++){
// 		     if((i==1 && j==6) || (i==2&&j==4) || (i==2 && j==7) ||(i==3 && j>2 &&j<=6) || (i==4 && j==2)||(i==4 && j==9) ){
// 		        System.out.print("*");
// 		       }
// 		       System.out.print(" ");
		       
// 		    }
// 		    System.out.println("");
// 		} 
// 	////////////////////////////////////////////
// 	System.out.println();

// 		System.out.println("For B: ");
// 		for (int i=1;i<=5 ;i++ ){
// 		    for(int j=1;j<=9;j++){
// 		     if((i==1 && j>1&&j<=6) || (i==2 && j==2) || (i==2 && j==9) ||(i==3 && j>1 &&j<=5) || (i==4 && j==2)||(i==4 && j==9)||(i==5 && j>1&&j<=6) ){
// 		        System.out.print("*");
// 		       }
// 		       System.out.print(" ");
// 		    }
// 		    System.out.println("");
// 		} 
// //////////////////////////////////////////
// System.out.println();

// 		System.out.println("For C: ");
// 		for (int i=1;i<=5 ;i++ ){
// 		    for(int j=1;j<=9;j++){
// 		     if((i==1 && j>2&&j<=6) || (i==2 && j==2) ||(i==3 && j==2 ) || (i==4 && j==2)||(i==5 && j>2&&j<=6) ){
// 		        System.out.print("*");
// 		       }
// 		       System.out.print(" ");
// 		    }
// 		    System.out.println("");
// 		} 
// ///////////////////////////////////////////
// System.out.println();

// 		System.out.println("For D: ");
// 		for (int i=1;i<=5 ;i++ ){
// 		    for(int j=1;j<=9;j++){
// 		     if((i==1 && j>1&&j<=5) || (i==2 && j==2) || (i==2 && j==9) ||(i==3 && j==2 ) || (i==4 && j==2)||(i==4 && j==9)||(i==5 && j>1&&j<=5) ){
// 		        System.out.print("*");
// 		       }
// 		       System.out.print(" ");
// 		    }
// 		    System.out.println("");
// 		} 
// ///////////////////////////////////////////
// System.out.println();

// 		System.out.println("For E: ");
// 		for (int i=1;i<=5 ;i++ ){
// 		    for(int j=1;j<=9;j++){
// 		     if((i==1 && j>1&&j<=6) || (i==2 && j==2) ||(i==3 && j>=2&&j<=6 ) || (i==4 && j==2)||(i==5 && j>1&&j<=6) ){
// 		        System.out.print("*");
// 		       }
// 		       System.out.print(" ");
// 		    }
// 		    System.out.println("");
// 		} 
// ///////////////////////////////////////////
// System.out.println();

// 		System.out.println("For F: ");
// 		for (int i=1;i<=5 ;i++ ){
// 		    for(int j=1;j<=9;j++){
// 		     if((i==1 && j>1&&j<=6) || (i==2 && j==2) ||(i==3 && j>=2&&j<=6 ) || (i==4 && j==2)||(i==5 && j==2) ){
// 		        System.out.print("*");
// 		       }
// 		       System.out.print(" ");
// 		    }
// 		    System.out.println("");
// 		} 
// ///////////////////////////////////////////
// System.out.println();

// 		System.out.println("For G: ");
// 		for (int i=1;i<=5 ;i++ ){
// 		    for(int j=1;j<=9;j++){
// 		     if((i==1 && j>1&&j<=6) || (i==2 && j==2) ||(i==3 && j>=2&&j<=6&&j!=3 ) || (i==4 && j==2)||(i==4 && j==9)||(i==5 && j==2) ||(i==5 && j>1&&j<=6) ){
// 		        System.out.print("*");
// 		       }
// 		       System.out.print(" ");
// 		       if(i==3&&j==3){
// 		           System.out.print(" ");
// 		       }
// 		    }
// 		    System.out.println("");
// 		} 
// ///////////////////////////////////////////
// System.out.println();

// System.out.println("For H: ");
// 		for (int i=1;i<=5 ;i++ ){
// 		    for(int j=1;j<=9;j++){
// 		     if((i==1 && j==2)||(i==1&&j==9) || (i==2 && j==2) ||(i==2&&j==9)||(i==3 && j>1&&j<=6 ) || (i==4 && j==2)||(i==4 && j==9)||(i==5 && j==2) ||(i==5 && j==2)||(i==5&&j==9) ){
// 		        System.out.print("*");
// 		       }
// 		       System.out.print(" ");
// 		    }
// 		    System.out.println("");
// 		} 
// ///////////////////////////////////////////
// System.out.println();

// System.out.println("For I: ");
// 		for (int i=1;i<=5 ;i++ ){
// 		    for(int j=1;j<=9;j++){
// 		     if((i==1 && j>1&&j<=6) || (i==2 && j==6)||(i==3 && j==6 ) || (i==4 && j==6)||(i==5 && j>1&&j<=6) ){
// 		        System.out.print("*");
// 		       }
// 		       System.out.print(" ");
// 		    }
// 		    System.out.println("");
// 		} 
// ///////////////////////////////////////////
// System.out.println();

// System.out.println("For J: ");
// 		for (int i=1;i<=5 ;i++ ){
// 		    for(int j=1;j<=9;j++){
// 		     if((i==1 && j>1&&j<=6) || (i==2 && j==6)||(i==3 && j==6 ) || (i==4 && j==5)|| (i==4 && j==2)||(i==5 && j>1&&j<=4) ){
// 		        System.out.print("*");
// 		       }
// 		       System.out.print(" ");
// 		    }
// 		    System.out.println("");
// 		} 
// ///////////////////////////////////////////
// System.out.println();

// System.out.println("For K: ");
// 		for (int i=1;i<=5 ;i++ ){
// 		    for(int j=1;j<=9;j++){
// 		     if((i==1 && j==2)||(i==1 && j==9) || (i==2 && j==2)|| (i==2 && j==5)||(i==3 && j==3)||(i==3 && j==2)||(i==4 && j==2)||(i==5 && j==2)|| (i==4 && j==5)|| (i==5 && j==9)){
// 		        System.out.print("*");
// 		       }
// 		       System.out.print(" ");
// 		    }
// 		    System.out.println("");
// 		}
// ///////////////////////////////////////////
// System.out.println();

// System.out.println("For L: ");
// 		for (int i=1;i<=5 ;i++ ){
// 		    for(int j=1;j<=9;j++){
// 		     if((i==1 && j==2) || (i==2 && j==2)|| (i==3 && j==2)||(i==4 && j==2)||(i==5 && j==2)|| (i==5 && j>1&&j<=6)){
// 		        System.out.print("*");
// 		       }
// 		       System.out.print(" ");
// 		    }
// 		    System.out.println("");
// 		}
// ///////////////////////////////////////////
// System.out.println();

// System.out.println("For M: ");
// 		for (int i=1;i<=5 ;i++ ){
// 		    for(int j=1;j<=9;j++){
// 		     if((i==1 && j==2)||(i==1&&j==9) || (i==2 && j==2) || (i==2 && j==3) ||(i==2&&j==6)||(i==2&&j==7)||(i==3 && j==2)||(i==3&&j==5 )||(i==3&&j==8 ) || (i==4 && j==2)||(i==4 && j==9)||(i==5 && j==2) ||(i==5 && j==2)||(i==5&&j==9) ){
// 		        System.out.print("*");
// 		       }
// 		       System.out.print(" ");
// 		    }
// 		    System.out.println("");
// 		} 
// ///////////////////////////////////////////
// System.out.println();

// System.out.println("For N: ");
// 		for (int i=1;i<=5 ;i++ ){
// 		    for(int j=1;j<=9;j++){
// 		     if((i==1 && j==2)||(i==1&&j==9) || (i==2 && j==2) || (i==2 && j==3) ||(i==3 && j==2)||(i==2 && j==8)||(i==3&&j==5 )||(i==3&&j==8 ) || (i==4 && j==2)||(i==4 && j==7)||(i==4 && j==8)||(i==5 && j==2) ||(i==5 && j==2)||(i==5&&j==9) ){
// 		        System.out.print("*");
// 		       }
// 		       System.out.print(" ");
// 		    }
// 		    System.out.println("");
// 		} 
// ///////////////////////////////////////////
// System.out.println();

// 	System.out.println("For O: ");
// 		for (int i=1;i<=5 ;i++ ){
// 		    for(int j=1;j<=9;j++){
// 		     if((i==1 && j>2&&j<=6) || (i==2 && j==2) ||(i==2 && j==9) ||(i==3 && j==2 )||(i==3 && j==9 ) || (i==4 && j==2)|| (i==4 && j==9)||(i==5 && j>2&&j<=6) ){
// 		        System.out.print("*");
// 		       }
// 		       System.out.print(" ");
// 		    }
// 		    System.out.println("");
// 		} 
// ///////////////////////////////////////////
// System.out.println();

// 	System.out.println("For P: ");
// 		for (int i=1;i<=5 ;i++ ){
// 		    for(int j=1;j<=9;j++){
// 		     if((i==1 && j>1&&j<=6) || (i==2 && j==2)|| (i==2 && j==9) ||(i==3 && j>=2&&j<=6 ) || (i==4 && j==2)||(i==5 && j==2) ){
// 		        System.out.print("*");
// 		       }
// 		       System.out.print(" ");
// 		    }
// 		    System.out.println("");
// 		} 
// ///////////////////////////////////////////
// System.out.println();

// 	System.out.println("For Q: ");
// 		for (int i=1;i<=5 ;i++ ){
// 		    for(int j=1;j<=9;j++){
// 		     if((i==1 && j>2&&j<=6) || (i==2 && j==2) ||(i==2 && j==9) ||(i==3 && j==2 )||(i==3 && j==8 )||(i==3 && j==5 ) || (i==4 && j==2)|| (i==4 && j==7)|| (i==4 && j==8)||(i==5 && j>2&&j<=6) ){
// 		        System.out.print("*");
// 		       }
// 		       System.out.print(" ");
// 		    }
// 		    System.out.println("");
// 		} 
// ///////////////////////////////////////////
// System.out.println();

// 	System.out.println("For R: ");
// 		for (int i=1;i<=5 ;i++ ){
// 		    for(int j=1;j<=9;j++){
// 		     if((i==1 && j>1&&j<=6) || (i==2 && j==2)|| (i==2 && j==9) ||(i==3 && j>=2&&j<=6 )||(i==4 && j==5 )||(i==5 && j== 9) || (i==4 && j==2)||(i==5 && j==2) ){
// 		        System.out.print("*");
// 		       }
// 		       System.out.print(" ");
// 		    }
// 		    System.out.println("");
// 		} 
// ///////////////////////////////////////////
// System.out.println();

// System.out.println("For S: ");
// 		for (int i=1;i<=5 ;i++ ){
// 		    for(int j=1;j<=9;j++){
// 		     if((i==1 && j>1&&j<=6) || (i==2 && j==2) ||(i==3 && j>=2&&j<=6 ) || (i==4 && j==9)||(i==5 && j>1&&j<=6) ){
// 		        System.out.print("*");
// 		       }
// 		       System.out.print(" ");
// 		       if(i==4&&j==2){
// 		           System.out.print(" ");
// 		       }
// 		    }
// 		    System.out.println("");
// 		} 
// ///////////////////////////////////////////
// System.out.println();

// System.out.println("For T: ");
// 		for (int i=1;i<=5 ;i++ ){
// 		    for(int j=1;j<=9;j++){
// 		     if((i==1 && j>1&&j<=6) || (i==2 && j==6)||(i==3 && j==6 ) || (i==4 && j==6)||(i==5 && j==6) ){
// 		        System.out.print("*");
// 		       }
// 		       System.out.print(" ");
// 		    }
// 		    System.out.println("");
// 		} 
// ///////////////////////////////////////////
// System.out.println();

// 	System.out.println("For U: ");
// 		for (int i=1;i<=5 ;i++ ){
// 		    for(int j=1;j<=9;j++){
// 		     if((i==1 && j==2) ||(i==1 && j==9)|| (i==2 && j==2) ||(i==2 && j==9) ||(i==3 && j==2 )||(i==3 && j==9 ) || (i==4 && j==2)|| (i==4 && j==9)||(i==5 && j>2&&j<=6) ){
// 		        System.out.print("*");
// 		       }
// 		       System.out.print(" ");
// 		    }
// 		    System.out.println("");
// 		} 
// ///////////////////////////////////////////
// System.out.println();

// System.out.println("For U: ");
// 		for (int i=1;i<=5 ;i++ ){
// 		    for(int j=1;j<=9;j++){
// 		     if((i==1 && j==2) ||(i==1 && j==9)|| (i==2 && j==3) ||(i==2 && j==8) ||(i==3 && j==4 )||(i==3 && j==7 ) || (i==4 && j==5)|| (i==4 && j==6)||(i==5 && j==6) ){
// 		        System.out.print("*");
// 		       }
// 		       System.out.print(" ");
// 		    }
// 		    System.out.println("");
// 		} 
// ///////////////////////////////////////////
// System.out.println();

// System.out.println("For W: ");
// 		for (int i=1;i<=5 ;i++ ){
// 		    for(int j=1;j<=9;j++){
// 		     if((i==1 && j==2)||(i==1&&j==9) || (i==2 && j==2)||(i==2&&j==9)||(i==3 && j==2)||(i==3&&j==5 )||(i==3&&j==8 ) || (i==4 && j==2)|| (i==4 && j==3)||(i==4&&j==6)||(i==4 && j==7)||(i==5 && j==2) ||(i==5 && j==2)||(i==5&&j==9) ){
// 		        System.out.print("*");
// 		       }
// 		       System.out.print(" ");
// 		    }
// 		    System.out.println("");
// 		} 
// ///////////////////////////////////////////
// System.out.println();

// System.out.println("For X: ");
// 		for (int i=1;i<=5 ;i++ ){
// 		    for(int j=1;j<=9;j++){
// 		     if((i==1 && j==2)||(i==1&&j==9) || (i==2 && j==4)||(i==2&&j==7)||(i==3&&j==6 )|| (i==4 && j==4)||(i==4&&j==7)||(i==5 && j==2) ||(i==5 && j==2)||(i==5&&j==9) ){
// 		        System.out.print("*");
// 		       }
// 		       System.out.print(" ");
// 		    }
// 		    System.out.println("");
// 		} 
// ///////////////////////////////////////////
// System.out.println();

// System.out.println("For Y: ");
// 		for (int i=1;i<=5 ;i++ ){
// 		    for(int j=1;j<=9;j++){
// 		     if((i==1 && j==2)||(i==1&&j==9) || (i==2 && j==4)||(i==2&&j==7)||(i==3&&j==6 )|| (i==4 && j==6)||(i==5 && j==6) ||(i==5 && j==6)){
// 		        System.out.print("*");
// 		       }
// 		       System.out.print(" ");
// 		    }
// 		    System.out.println("");
// 		} 
// ///////////////////////////////////////////
// System.out.println();
// System.out.println("For Z: ");
// 		for (int i=1;i<=5 ;i++ ){
// 		    for(int j=1;j<=9;j++){
// 		     if((i==1 && j>1&&j<=6) ||(i==2&&j==8)||(i==3&&j==6 )|| (i==4 && j==4)||(i==5 && j==2) ||(i==5 && j==2)||(i==5&&j>1&&j<=6) ){
// 		        System.out.print("*");
// 		       }
// 		       System.out.print(" ");
// 		    }
// 		    System.out.println("");
// 		} 
// ///////////////////////////////////////////

		
		
// 	}
// }

    
    //   System.out.println(m2);
    //   System.out.println(m3);

