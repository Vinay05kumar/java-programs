/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
    public class tv{
    int b,v;
    tv(){
        
        this.b=50;
        this.v=30;
    }
    tv(int br,int vo){
        
        this.b=br;
        this.v=vo;
    }
    void volume_br(int vo){
        this.b=vo;
    }
    void update_vo(int br){
        this.b=br;
    }
	public static void main(String[] args) {
		
		tv m1=new tv();
		tv t2=new tv(80,50);
		System.out.println(m1.b);
				System.out.println(m1.v);
		System.out.println(t2.b);
		System.out.println(t2.v);
	}
}
    
    
// 	public static void main(String[] args) {
// 	    Scanner s1=new Scanner(System.in);
// 	    int n=s1.nextInt();
	    
	   // int arr[]=new int[n];
	   // for(int i=0;i<n;i++){
	   //     arr[i]=s1.nextInt();
	   // }
	   // int sum=0;
	   // for(int i=0;i<n;i++){
	   //     sum+=arr[i]*Math.pow(2,n-i-1);
	       
	   // }
	   // System.out.println(sum);
	    
	   
	    
	    
	   // for(int i=1;i<=n;i++){
	   //     int a=s1.nextInt();
	   //     int b=s1.nextInt();
	   //     int count=0;
	   //     for(int j=a;j<=b;j++){
	   //         int digit=0;
	   //         digit=j%10;
	   //         if(digit==2||digit==3||digit==9){
	   //             count++;
	   //         }
	            
	   //     }
	   //     System.out.println(count);
	        
	   // }
	    
// 	    int sum=0;
// 	    for(int i=1;i<=n/2;i++){
// 	        if(n%i==0){
// 	            sum+=i;
// 	        }
	        
// 	    }
// 	        if(n==sum){
// 	            System.out.println("p");
// 	        }else if(n>sum){
// 	            System.out.println("A");
// 	        }else{
// 	            System.out.println("D");
// 	        }
// 	}
// }